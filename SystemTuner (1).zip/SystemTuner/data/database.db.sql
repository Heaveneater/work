-- Создание таблицы преподавателей
CREATE TABLE IF NOT EXISTS Prepodavately (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    Фамилия TEXT NOT NULL,
    Имя TEXT NOT NULL,
    Отчество TEXT,
    Дисциплины TEXT
);

-- Создание таблицы спортивных секций
CREATE TABLE IF NOT EXISTS sport (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    description TEXT,
    location TEXT,
    schedule TEXT,
    teacher TEXT
);

-- Создание таблицы общежитий
CREATE TABLE IF NOT EXISTS obshejitie (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    number TEXT NOT NULL,
    warden TEXT, -- Комендант
    address TEXT,
    phone TEXT,
    info TEXT
);

-- Создание таблицы мероприятий
CREATE TABLE IF NOT EXISTS Meropryitiay (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    date TEXT NOT NULL,
    title TEXT NOT NULL,
    location TEXT
);

-- Создание таблицы документов и справок
CREATE TABLE IF NOT EXISTS document (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    description TEXT,
    how_to_get TEXT,
    required_docs TEXT
);

-- Создание таблицы FAQ
CREATE TABLE IF NOT EXISTS faq (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    question TEXT NOT NULL,
    answer TEXT NOT NULL
);

-- Создание таблицы навигации по колледжу
CREATE TABLE IF NOT EXISTS navigate (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    Библиотека TEXT,
    VR TEXT,
    "Учебная часть" TEXT,
    Столовая TEXT,
    "Студенческий совет" TEXT,
    Бухгалтерия TEXT,
    Дополнительно TEXT
);

-- Создание таблицы аудиторий
CREATE TABLE IF NOT EXISTS auditoria (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    Номер TEXT NOT NULL,
    Этаж TEXT,
    Корпус TEXT,
    Описание TEXT
);

-- Вставка примерных данных о преподавателях
INSERT INTO Prepodavately (Фамилия, Имя, Отчество, Дисциплины) VALUES
('Иванов', 'Иван', 'Иванович', 'Математика, Информатика, МДК 01.01 Программирование'),
('Петрова', 'Мария', 'Сергеевна', 'Русский язык, Литература'),
('Сидоров', 'Алексей', 'Петрович', 'История, Обществознание');

-- Вставка примерных данных о спортивных секциях
INSERT INTO sport (name, description, location, schedule, teacher) VALUES
('Волейбол', 'Секция волейбола для начинающих и продолжающих', 'Спортзал №1', 'Понедельник, среда, пятница 16:00-18:00', 'Смирнов А.В.'),
('Баскетбол', 'Мужская и женская команды', 'Спортзал №2', 'Вторник, четверг 16:00-18:00', 'Кузнецов М.И.'),
('Футбол', 'Тренировки на свежем воздухе', 'Стадион', 'Среда, пятница 15:00-17:00', 'Новиков С.Д.');

-- Вставка примерных данных об общежитиях
INSERT INTO obshejitie (number, warden, address, phone, info) VALUES
('1', 'Соколова Ирина Васильевна', 'ул. Ленина, 10', '+7 (342) 555-1234', 'Общежитие для юношей'),
('2', 'Васильев Петр Андреевич', 'ул. Пушкина, 15', '+7 (342) 555-5678', 'Общежитие для девушек');

-- Вставка примерных данных о мероприятиях
INSERT INTO Meropryitiay (date, title, location) VALUES
('15.09.2024', 'День первокурсника', 'Актовый зал'),
('05.10.2024', 'День учителя', 'Актовый зал'),
('30.10.2024', 'Хэллоуин', 'Столовая');

-- Вставка примерных данных о документах
INSERT INTO document (name, description, how_to_get, required_docs) VALUES
('Справка об обучении', 'Справка, подтверждающая обучение в колледже', 'Обратиться в учебную часть, каб. 205', ''),
('Студенческий билет', 'Документ, удостоверяющий статус студента', 'Обратиться к секретарю учебной части', 'Паспорт, фото 3х4'),
('Зачетная книжка', 'Документ учета успеваемости студента', 'Выдается у куратора группы', '');

-- Вставка примерных данных в FAQ
INSERT INTO faq (question, answer) VALUES
('Как получить студенческий билет?', 'Для получения студенческого билета необходимо обратиться к секретарю учебной части (каб. 205) с паспортом и фотографией 3x4.'),
('Где находится библиотека?', 'Библиотека расположена на 2 этаже главного корпуса, кабинет 215.'),
('Как записаться в спортивную секцию?', 'Для записи в спортивную секцию обратитесь к преподавателю физкультуры или непосредственно к руководителю секции.');

-- Вставка примерных данных о навигации
INSERT INTO navigate (Библиотека, VR, "Учебная часть", Столовая, "Студенческий совет", Бухгалтерия) VALUES
('2 этаж, кабинет 215', '3 этаж, кабинет 301', '2 этаж, кабинет 205', '1 этаж, западное крыло', '3 этаж, кабинет 315', '1 этаж, кабинет 102');

-- Вставка примерных данных об аудиториях
INSERT INTO auditoria (Номер, Этаж, Корпус, Описание) VALUES
('101', '1', 'Главный', 'Лекционная аудитория'),
('205', '2', 'Главный', 'Учебная часть'),
('215', '2', 'Главный', 'Библиотека'),
('301', '3', 'Главный', 'VR-лаборатория');
