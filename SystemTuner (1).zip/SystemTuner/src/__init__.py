#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Пакет SystemTuner - Telegram-бот для студентов Пермского финансово-экономического колледжа.
"""