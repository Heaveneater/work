#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Точка входа для Telegram-бота студентов Пермского финансово-экономического колледжа.
"""

from src.main import init_app

# Инициализируем приложение для Gunicorn
app = init_app()

if __name__ == "__main__":
    # Запускаем приложение напрямую в режиме отладки
    app.run(host="0.0.0.0", port=5000, debug=True)